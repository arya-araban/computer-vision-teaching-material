clear;

pointProcessing({'lighten'});